import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'
import OpenAI from 'openai'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

const openai = new OpenAI({
  apiKey: process.env.OPENROUTER_API_KEY!,
  baseURL: 'https://openrouter.ai/api/v1',
  defaultHeaders: {
    'HTTP-Referer': 'https://celtaprep.com',
    'X-Title': 'CELTA Prep Morocco',
  },
})

const EMBEDDING_MODEL = 'openai/text-embedding-3-small' // MUST match upload-docs.ts

// ── Query classification ───────────────────────────────────────────────────────
interface QueryClass {
  category: string | null
  intent: string
  target_type: string
}

function classifyQuery(query: string): QueryClass {
  const q = query.toLowerCase()

  let category: string | null = null
  if (q.match(/celta|teaching practice|\btp\b|lesson plan|ccq|icq|concept check/)) category = 'celta'
  else if (q.match(/delta|diploma|\blsa\b|\bpda\b|observed lesson|background essay/)) category = 'delta'
  else if (q.match(/classroom management|discipline|behaviour|seating|routine/)) category = 'classroom_mgmt'
  else if (q.match(/phonolog|pronunciation|phoneme|stress|intonation|consonant|vowel/)) category = 'phonology'
  else if (q.match(/\bgrammar\b|tense|aspect|syntax|morpholog/)) category = 'linguistics'
  else if (q.match(/methodology|approach|\bppp\b|\btbl\b|\besa\b|communicative|harmer|scrivener/)) category = 'methodology'
  else if (q.match(/vocabular|lexis|collocation|\bword\b|lexical/)) category = 'vocabulary'
  else if (q.match(/reading|writing|listening|speaking|receptive|productive/)) category = 'skills'

  let intent = 'general'
  if (q.match(/^how|how (should|do|can|to)|what (steps|procedure|process)|technique|method/)) intent = 'how_to'
  else if (q.match(/what (are|is) (the )?(key |main |core )?requirement|criteria|standard|descriptor|pass|grade/)) intent = 'requirements'
  else if (q.match(/what (is|are|does|do)|define|definition|explain|meaning of/)) intent = 'definition'
  else if (q.match(/difference|compare|vs|versus|contrast|better/)) intent = 'comparison'
  else if (q.match(/example|show me|give me|sample|illustrate/)) intent = 'example'
  else if (q.match(/avoid|mistake|problem|challenge|pitfall|wrong|error/)) intent = 'warning'

  let target_type = 'explanation'
  if (intent === 'how_to') target_type = 'procedure'
  else if (intent === 'requirements') target_type = 'assessment_criteria'
  else if (intent === 'example') target_type = 'example'
  else if (intent === 'warning') target_type = 'warning'
  else if (intent === 'definition') target_type = 'definition'

  return { category, intent, target_type }
}

// ── Heuristic reranker ────────────────────────────────────────────────────────
interface RawChunk {
  id: number
  document_id: number
  content: string
  chapter: string
  section: string
  heading_path: string
  chunk_type: string
  keywords: string[]
  category: string
  title: string
  author: string
  similarity: number
}

function rerank(chunks: RawChunk[], query: string, qClass: QueryClass): RawChunk[] {
  const q = query.toLowerCase()
  const queryWords = q.split(/\s+/).filter(w => w.length > 3)

  return chunks
    .map(chunk => {
      let score = chunk.similarity * 10

      if (chunk.chunk_type === qClass.target_type) score += 2.5
      if (qClass.category && chunk.category === qClass.category) score += 1.5

      const hp = (chunk.heading_path || '').toLowerCase()
      for (const word of queryWords) {
        if (hp.includes(word)) score += 0.8
      }

      const kws = (chunk.keywords || []).map(k => k.toLowerCase())
      for (const kw of kws) {
        if (q.includes(kw)) score += 0.5
      }

      const content = chunk.content.toLowerCase()
      if (content.includes(q.slice(0, 30))) score += 1.0
      if (qClass.intent === 'how_to' && content.match(/step|firstly|secondly|then|next|finally/)) score += 0.7
      if (chunk.content.length < 150) score -= 1.0

      return { ...chunk, _score: score }
    })
    .sort((a: any, b: any) => b._score - a._score)
}

function dedupeBySource(chunks: RawChunk[], maxPerDoc = 2): RawChunk[] {
  const countByDoc: Record<number, number> = {}
  return chunks.filter(c => {
    countByDoc[c.document_id] = (countByDoc[c.document_id] || 0) + 1
    return countByDoc[c.document_id] <= maxPerDoc
  })
}

// ── Main route ────────────────────────────────────────────────────────────────
export async function POST(req: NextRequest) {
  try {
    const { query } = await req.json()
    if (!query) return NextResponse.json({ error: 'No query provided' }, { status: 400 })

    const qClass = classifyQuery(query)

    // 1. Embed query
    const embeddingResponse = await openai.embeddings.create({
      model: EMBEDDING_MODEL,
      input: query,
    })
    const queryEmbedding = embeddingResponse.data[0].embedding

    // 2. Semantic cache check — return instantly if similar query was answered before
    const { data: cached } = await supabase.rpc('match_cache', {
      query_embedding: queryEmbedding,
      similarity_threshold: 0.92,
      match_count: 1,
    })

    if (cached && cached.length > 0) {
      // Bump hit count in background
      supabase
        .from('query_cache')
        .update({ hit_count: cached[0].hit_count + 1, last_hit_at: new Date().toISOString() })
        .eq('id', cached[0].id)
        .then(() => {})

      return NextResponse.json({
        answer: cached[0].answer,
        sources: cached[0].sources,
        cached: true,
      })
    }

    // 3. Retrieve top 20 candidates
    let { data: chunks, error } = await supabase.rpc('match_chunks', {
      query_embedding: queryEmbedding,
      match_count: 20,
      filter_category: qClass.category,
      filter_chunk_type: null,
    })

    // 4. Fallback to all categories if not enough results
    if ((!chunks || chunks.length < 3) && qClass.category !== null) {
      const fallback = await supabase.rpc('match_chunks', {
        query_embedding: queryEmbedding,
        match_count: 20,
        filter_category: null,
        filter_chunk_type: null,
      })
      chunks = fallback.data
      error = fallback.error
    }

    if (error) {
      console.error('Supabase search error:', error)
      return NextResponse.json({ error: 'Search failed' }, { status: 500 })
    }

    if (!chunks || chunks.length === 0) {
      return NextResponse.json({
        answer: "I don't have information on that topic yet. Try asking about CELTA teaching practice, DELTA requirements, classroom management, or methodology.",
      })
    }

    // 5. Rerank + dedupe + top 5
    const reranked = rerank(chunks as RawChunk[], query, qClass)
    const top = dedupeBySource(reranked, 2).slice(0, 5)

    // 6. Build context
    const context = top
      .map((c, i) => {
        const loc = [c.chapter, c.section].filter(Boolean).join(' › ')
        return `[${i + 1}] ${c.title}${loc ? ` — ${loc}` : ''} (${c.chunk_type})\n${c.content}`
      })
      .join('\n\n---\n\n')

    // 7. Synthesise
    const completion = await openai.chat.completions.create({
      model: 'openai/gpt-4o-mini',
      max_tokens: 220,
      messages: [
        {
          role: 'system',
          content: `You are an expert CELTA and DELTA teacher trainer answering a practicing teacher's question.

Use ONLY the provided source material. Follow these rules:
- Answer in natural spoken English — this will be read aloud
- 80–120 words maximum
- No bullet points, no markdown, no headers
- Give at least one specific, concrete classroom action where the source supports it
- Do NOT generalize if the source is specific — use the specific detail
- If the source doesn't clearly answer the question, say so in one sentence and suggest what to ask instead
- Speak directly to the teacher as "you"
- Cite the source title naturally in the answer (e.g. "According to Harmer...")`,
        },
        {
          role: 'user',
          content: `Question: ${query}\n\nIntent: ${qClass.intent} (looking for ${qClass.target_type})\n\nSource material:\n${context}`,
        },
      ],
    })

    const answer = completion.choices[0]?.message?.content || ''
    const sources = [...new Set(top.map(c => c.title))]

    // 8. Save to cache for future identical/similar queries
    supabase
      .from('query_cache')
      .insert({
        query_text: query,
        query_embedding: JSON.stringify(queryEmbedding),
        answer,
        sources,
        category: qClass.category,
        intent: qClass.intent,
      })
      .then(() => {})

    return NextResponse.json({
      answer,
      sources,
      cached: false,
      debug: {
        category: qClass.category,
        intent: qClass.intent,
        target_type: qClass.target_type,
        chunks_retrieved: chunks.length,
        chunks_used: top.length,
      },
    })
  } catch (err: any) {
    console.error('voice-query error:', err)
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}
